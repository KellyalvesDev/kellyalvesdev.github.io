function copyEmail() {
  navigator.clipboard.writeText('kellytalvesp@gmail.com');
  alert('E-mail copiado para a área de transferência!');
}

function toggleDarkMode() {
  document.body.classList.toggle('dark');
}